import { supabase } from './supabaseClient.js'

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('form-stands')
    const mensajeExito = document.getElementById('stand-mensaje')
    const submitBtn = form ? form.querySelector('.form-submit') : null

    if (!form) return

    form.addEventListener('submit', async (e) => {
        e.preventDefault()

        // 1. Obtener los valores de los inputs
        const nombreInput = document.getElementById('stand-nombre')
        const correoInput = document.getElementById('stand-correo')
        const telefonoInput = document.getElementById('stand-telefono')
        const rubroInput = document.getElementById('stand-rubro')
        const diaInput = document.getElementById('stand-dia')
        const tamanoRadio = document.querySelector('input[name="stand-tamano"]:checked')
        const descripcionInput = document.getElementById('stand-descripcion')
        const aceptoInput = document.getElementById('stand-acepto')

        // 2. Validaciones básicas
        if (!nombreInput.value.trim() || !correoInput.value.trim() || !rubroInput.value || !diaInput.value || !tamanoRadio || !aceptoInput.checked) {
            alert('Por favor, completa todos los campos requeridos y acepta las condiciones.')
            return
        }

        // 3. Deshabilitar botón durante el envío
        if (submitBtn) {
            submitBtn.disabled = true
            submitBtn.textContent = 'Enviando...'
        }

        // 4. Enviar a la tabla "stands" en Supabase
        const { data, error } = await supabase
            .from('stands')
            .insert([
                {
                    nombre: nombreInput.value.trim(),
                    correo: correoInput.value.trim(),
                    telefono: telefonoInput.value.trim(),
                    rubro: rubroInput.value,
                    dia: diaInput.value,
                    tamano: tamanoRadio.value,
                    descripcion: descripcionInput.value.trim()
                }
            ])

        // 5. Manejar respuesta
        if (error) {
            console.error('Error al insertar en Supabase:', error.message)
            alert('Hubo un error al guardar la reserva: ' + error.message)
        } else {
            if (mensajeExito) {
                mensajeExito.removeAttribute('hidden')
            }
            alert('¡Reserva de stand recibida con éxito!')
            form.reset()
        }

        // Restaurar botón
        if (submitBtn) {
            submitBtn.disabled = false
            submitBtn.textContent = 'Reservar mi stand'
        }
    })
})