import { supabase } from './supabaseClient.js'

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('form-preinscripcion')
    const mensajeExito = document.getElementById('pre-mensaje')
    const submitBtn = form ? form.querySelector('.form-submit') : null

    if (!form) return

    form.addEventListener('submit', async (e) => {
        e.preventDefault()

        // 1. Obtener elementos del DOM
        const nombreInput = document.getElementById('pre-nombre')
        const correoInput = document.getElementById('pre-correo')
        const telefonoInput = document.getElementById('pre-telefono')
        const actividadInput = document.getElementById('pre-actividad')
        const asistentesInput = document.getElementById('pre-asistentes')
        const comentariosInput = document.getElementById('pre-comentarios')
        const aceptoInput = document.getElementById('pre-acepto')

        // 2. Validaciones básicas
        if (!nombreInput.value.trim() || !correoInput.value.trim() || !aceptoInput.checked) {
            alert('Por favor, completa los campos requeridos y acepta los términos.')
            return
        }

        // 3. Deshabilitar botón durante el envío
        if (submitBtn) {
            submitBtn.disabled = true
            submitBtn.textContent = 'Enviando...'
        }

        // 4. Enviar a Supabase
        const { data, error } = await supabase
            .from('preinscripciones')
            .insert([
                {
                    nombre: nombreInput.value.trim(),
                    correo: correoInput.value.trim(),
                    telefono: telefonoInput.value.trim(),
                    actividad: actividadInput.value,
                    asistentes: parseInt(asistentesInput.value, 10),
                    comentarios: comentariosInput.value.trim()
                }
            ])

        // 5. Manejo de respuesta
        if (error) {
            console.error('Error al insertar en Supabase:', error.message)
            alert('Hubo un error al guardar la preinscripción: ' + error.message)
        } else {
            if (mensajeExito) {
                mensajeExito.removeAttribute('hidden')
            }
            alert('¡Preinscripción enviada con éxito!')
            form.reset()
        }

        // Restaurar botón
        if (submitBtn) {
            submitBtn.disabled = false
            submitBtn.textContent = 'Enviar preinscripción'
        }
    })
})